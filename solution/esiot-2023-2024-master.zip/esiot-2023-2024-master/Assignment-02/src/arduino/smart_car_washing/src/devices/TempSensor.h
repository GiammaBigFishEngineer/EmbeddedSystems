#ifndef __TEMP_SENSOR__
#define __TEMP_SENSOR__

class TempSensor {

public:
  virtual float getTemperature() = 0;
  
};


#endif

