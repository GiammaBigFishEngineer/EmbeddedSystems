#ifndef __RUNNABLE__
#define __RUNNABLE__

class Runnable {
  
  virtual void run() = 0;
  
};

#endif

