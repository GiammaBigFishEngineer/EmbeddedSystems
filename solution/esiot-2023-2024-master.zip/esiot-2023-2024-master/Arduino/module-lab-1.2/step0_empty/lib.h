#ifndef __LIB_H__
#define __LIB_H__

extern int publicFlag;

/* public */
int myfunc(int x);

#endif
