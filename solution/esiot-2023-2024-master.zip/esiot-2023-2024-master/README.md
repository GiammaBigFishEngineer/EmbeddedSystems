# Embedded Systems and IoT
Repository for the course "Embedded Systems and IoT" a.y. 2023-2024. CdL Ingegneria e Scienze Informatiche - University of Bologna, Cesena Campus
